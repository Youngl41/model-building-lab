#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 18:27:15 2017

@author: Young
"""

from ..utility.general import set_title
helper_text = 'A feature class should map a single data point to a feature vector.'

set_title('Features')
print(helper_text)